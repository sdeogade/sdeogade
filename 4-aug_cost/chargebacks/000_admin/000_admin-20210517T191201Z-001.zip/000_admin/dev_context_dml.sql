------------------------------------------------------------------------------
-- context
--
!print set environment context

!define l_common_db=gsdmed_dev_common_db
!define l_common_schema=util

!define l_raw_db=gsdmed_dev_rl_snowflake_db
!define l_raw_schema=account_usage

!define l_il_db=gsdmed_dev_il_db
!define l_il_schema=main

!define l_pl_db=gsdmed_dev_pl_db
!define l_pl_schema=main

use warehouse gsdmed_dev_service_elt_wh;
alter warehouse gsdmed_dev_service_elt_wh set warehouse_size=large;

!print SUCCESS!
