------------------------------------------------------------------------------
-- 000_admin
--
!print 000_admin

-- upload hulu team warehouse mapping
!source 000_admin/hulu_team_warehouse_mapping_lkp_put.sql

!print SUCCESS!
