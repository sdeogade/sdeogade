--------------------------------------------------------------------
--  Purpose: Internal stage for accout_usage data
--
--  Revision History:
--  Date     Engineer      Description
--  -------- ------------- ----------------------------------
--  dd/mm/yy
--------------------------------------------------------------------

--
--upload hulu mapping table
--
put 'file://./hulu_team_warehouse_mapping_lkp.csv' @&{l_common_db}.&{l_common_schema}.account_usage_stg;

list @&{l_common_db}.&{l_common_schema}.account_usage_stg;


