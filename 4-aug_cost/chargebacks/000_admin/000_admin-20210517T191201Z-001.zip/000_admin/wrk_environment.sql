--------------------------------------------------------------------
--  Purpose: Internal stage for accout_usage data
--
--  Revision History:
--  Date     Engineer      Description
--  -------- ------------- ----------------------------------
--  dd/mm/yy
--------------------------------------------------------------------

--
-- drop schema gsitzman_db.cost_trans;
--
--create schema if not exists &{l_target_db}.&{l_target_schema};

