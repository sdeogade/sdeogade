--------------------------------------------------------------------
--  Purpose: Internal stage for accout_usage data
--
--  Revision History:
--  Date     Engineer      Description
--  -------- ------------- ----------------------------------
--  dd/mm/yy
--------------------------------------------------------------------

--
--
--create schema if not exists &{l_target_db}.&{l_target_schema};

