------------------------------------------------------------------------------
-- context
--
!print set environment context

!define l_common_db=DEV_PLAT_GOV_COMMON_DB
!define l_common_schema=UTIL

!define l_raw_db=DEV_PLAT_GOV_RL_DB
!define l_raw_schema=account_usage

!define l_il_db=DEV_PLAT_GOV_IL_DB
!define l_il_schema=USAGE_METRIC

!define l_pl_db=DEV_PLAT_GOV_PL_DB
!define l_pl_schema=REPORTING

!print SUCCESS!
